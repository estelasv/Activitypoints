<?php
	/**
	 * activitypoint CSS
	 */
?>

.activitypoints_profile{
    font-weight: bold; 
    padding: 3px 0 3px 5px;
    margin-top: 10px;
    background:white;
}

/* ------ activitypoints widgets ------  */

#activitypoints_mypoints_widget_container {
    text-align:left;
}

#activitypoints_toppoints_widget_container {
    text-align:left;
    /* background-color:#00ffff; */
}
    
.activitypoints_actions h3 {
    color:#4690D6;
}
.activitypoints_actions label {
    font-size:12px;
}
